﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

namespace PDisasters0030482323031
{
    internal class Cidade
    {
        //propriedade

        public int MyProperty { get; set; }

        public int IdCidade { get; set; }
        public string Nome { get; set; }
        public string Uf {  get; set; }
        
        public int Populacao { get; set; }

        public DataTable Listar()
        {
            SqlDataAdapter daCidade;
            DataTable dtCidade = new DataTable();

            try
            {
                daCidade = new SqlDataAdapter("SELECT * FROM Cidade " +
                    "ORDER BY nome", frmPrincipal.conexao);
                daCidade.Fill(dtCidade);
                daCidade.FillSchema(dtCidade, SchemaType.Source);
            }
            catch (Exception)
            {
                throw;
            }
            return dtCidade;
        }

        public int Incluir() // inclusao
        {
            int retorno = 0;

            try
            {
                SqlCommand mycommand;
                mycommand = new SqlCommand("INSERT INTO Cidade VALUES " +
                    "(@NOME, @UF, @POPULACAO)",
                    frmPrincipal.conexao);

                mycommand.Parameters.Add(new SqlParameter("@NOME",
                    SqlDbType.VarChar));

                mycommand.Parameters.Add(new SqlParameter("@UF",
                    SqlDbType.Char));
                mycommand.Parameters.Add(new SqlParameter("@POPULACAO",
                    SqlDbType.Int));

                mycommand.Parameters["@NOME"].Value = Nome;
                mycommand.Parameters["@UF"].Value = Uf;
                mycommand.Parameters["@POPULACAO"].Value = Populacao;

                retorno = mycommand.ExecuteNonQuery();
            }
            catch (Exception)
            {
                throw;
            }
            return retorno;
        }

        public int Alterar()
        {
            int retorno = 0;

            try
            {
                SqlCommand mycommand;

                mycommand = new SqlCommand("UPDATE Cidade SET NOME=@NOME, UF=@UF, POPULACAO=@POPULACAO WHERE IDCidade=@IDCIDADE", frmPrincipal.conexao);

                mycommand.Parameters.Add(new SqlParameter("@IDCIDADE", SqlDbType.Int));
                mycommand.Parameters.Add(new SqlParameter("@NOME", SqlDbType.VarChar));
                mycommand.Parameters.Add(new SqlParameter("@UF", SqlDbType.Char));
                mycommand.Parameters.Add(new SqlParameter("@POPULACAO", SqlDbType.Int));

                mycommand.Parameters["@IDCIDADE"].Value = IdCidade;
                mycommand.Parameters["@NOME"].Value = Nome;
                mycommand.Parameters["@UF"].Value = Uf;
                mycommand.Parameters["@POPULACAO"].Value = Populacao;

                retorno = mycommand.ExecuteNonQuery();
            }
            catch (Exception)
            {
                throw;
            }
            return retorno;
        }

        public int Excluir()
        {
            int nReg = 0;

            try
            {
                SqlCommand mycommand;

                mycommand = new SqlCommand("DELETE FROM Cidade WHERE IDCidade=@IDCidade", frmPrincipal.conexao);

                mycommand.Parameters.Add(new SqlParameter("@IDCidade", SqlDbType.Int));
                mycommand.Parameters["@IDCidade"].Value = IdCidade;

                nReg = mycommand.ExecuteNonQuery();
            }
            catch (Exception)
            {
                throw;
            }
            return nReg;
        }
    }

}

