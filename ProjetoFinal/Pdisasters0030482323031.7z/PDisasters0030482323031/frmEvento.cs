﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PDisasters0030482323031
{
    public partial class frmEvento : Form
    {
        private BindingSource bnEvento = new BindingSource();
        private bool bInclusao = false;
        private DataSet dsEvento = new DataSet();
       
        private DataSet dsTipo = new DataSet();

        public frmEvento()
        {
            InitializeComponent();
        }

        private void frmEvento_Load(object sender, EventArgs e)
        {
            try
            {
                Evento Eve = new Evento();
                dsEvento.Tables.Add(Eve.Listar());
                bnEvento.DataSource = dsEvento.Tables["Evento"];
                dgvEvento.DataSource = bnEvento;
                bnvTipo.BindingSource = bnEvento;

                txtIDEvento.DataBindings.Add("TEXT", bnEvento, "idEvento");
                cbxNivelSeveridade.DataBindings.Add("SelectedItem", bnEvento, "nivelseveridade");
                mskBxAreaAfetada.DataBindings.Add("TEXT", bnEvento, "areaafetada");
                mskBxPopAfetada.DataBindings.Add("TEXT", bnEvento, "pessoasafetadas");
                txtObservacao.DataBindings.Add("TEXT", bnEvento, "observacao");
                dtpDataOcorrencia.DataBindings.Add("TEXT", bnEvento, "dataocorrencia");

                // ligando com Evade
                Cidade Cid = new Cidade();
                dsEvento.Tables.Add(Cid.Listar());
                cbxCidade.DataSource = dsEvento.Tables["Cidade"];
                cbxCidade.DisplayMember = "nome";
                cbxCidade.ValueMember = "idcidade";
                cbxCidade.DataBindings.Add("SelectedValue", bnEvento, "cidade_idcidade");

                // ligando com Tipo
                Tipo Tip = new Tipo();
                dsTipo.Tables.Add(Tip.Listar());
                cbxTipo.DataSource = dsTipo.Tables["Tipo"];
                cbxTipo.DisplayMember = "descricao";
                cbxTipo.ValueMember = "idtipo";
                cbxTipo.DataBindings.Add("SelectedValue", bnEvento, "tipo_idtipo");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnNovo_Click(object sender, EventArgs e)
        {
            if (tbEvento.SelectedIndex == 0)
            {
                tbEvento.SelectTab(1);
            }
            bnEvento.AddNew();

            cbxCidade.Enabled = true;
            cbxTipo.Enabled = true;
            cbxCidade.SelectedIndex = 0;
            cbxTipo.SelectedIndex = 0;
            cbxNivelSeveridade.Enabled = true;
            cbxNivelSeveridade.SelectedIndex = 0;
            mskBxPopAfetada.Enabled = true;
            mskBxAreaAfetada.Enabled = true;
            txtObservacao.Enabled = true;
            dtpDataOcorrencia.Enabled = true;

            cbxTipo.Focus();

            btnSalvar.Enabled = true;
            btnAlterar.Enabled = false;
            btnNovo.Enabled = false;
            btnExcluir.Enabled = false;
            btnCancelar.Enabled = true;
            bInclusao = true;
        }

        private void btnAlterar_Click(object sender, EventArgs e)
        {
            if (tbEvento.SelectedIndex == 0)
            {
                tbEvento.SelectTab(1);
            }
            cbxCidade.Enabled = true;
            cbxTipo.Enabled = true;
            cbxNivelSeveridade.Enabled = true;
            mskBxPopAfetada.Enabled = true;
            mskBxAreaAfetada.Enabled = true;
            txtObservacao.Enabled = true;
            dtpDataOcorrencia.Enabled = true;
            cbxTipo.Focus();
            btnSalvar.Enabled = true;
            btnAlterar.Enabled = false;
            btnNovo.Enabled = false;
            btnExcluir.Enabled = false;
            btnCancelar.Enabled = true;
            bInclusao = false;
        }


        private void btnSalvar_Click(object sender, EventArgs e)
        {

            int area = 0;
            int pessoas = 0;
            DateTime data = DateTime.Today;

            // validar os dados
            if (txtObservacao.Text == "")
            {
                MessageBox.Show("Observação inválida!");
            }
            else if (!int.TryParse(mskBxAreaAfetada.Text, out area))
            {
                MessageBox.Show("Área afetada inválida!");
            }
            else if (!int.TryParse(mskBxPopAfetada.Text, out pessoas))
            {
                MessageBox.Show("Nº pessoas afetadas inválido!");
            }
            else if (!DateTime.TryParse(dtpDataOcorrencia.Text, out data) ||
                data > DateTime.Today)
            {
                MessageBox.Show("Data evento inválida!");
            }
            else
            {
                Evento RegEv = new Evento();

                RegEv.Tipo_IdTipo = Convert.ToInt32(cbxTipo.SelectedValue.ToString());
                RegEv.Cidade_IdCidade = Convert.ToInt32(cbxCidade.SelectedValue.ToString());
                RegEv.NivelSeveridade = Convert.ToChar(cbxNivelSeveridade.SelectedItem.ToString());
                RegEv.AreaAfetada = Convert.ToInt32(mskBxAreaAfetada.Text);
                RegEv.PessoasAfetadas = Convert.ToInt32(mskBxPopAfetada.Text);
                RegEv.Observacao = txtObservacao.Text;
                RegEv.DataOcorrencia = Convert.ToDateTime(dtpDataOcorrencia.Value);


                if (bInclusao)
                {
                    if (RegEv.Incluir() > 0)
                    {
                        MessageBox.Show("Evento adicionado com sucesso!");
                        cbxCidade.Enabled = false;
                        cbxTipo.Enabled = false;
                        cbxNivelSeveridade.Enabled = false;
                        mskBxPopAfetada.Enabled = false;
                        mskBxAreaAfetada.Enabled = false;
                        txtObservacao.Enabled = false;
                        dtpDataOcorrencia.Enabled = false;

                        btnSalvar.Enabled = false;
                        btnAlterar.Enabled = true;
                        btnNovo.Enabled = true;
                        btnExcluir.Enabled = true;
                        btnCancelar.Enabled = true;
                        bInclusao = false;

                        Evento R = new Evento();
                        dsEvento.Tables.Clear();
                        dsEvento.Tables.Add(R.Listar());
                        bnEvento.DataSource = dsEvento.Tables["Evento"];

                    }
                    else
                    {
                        MessageBox.Show("Erro ao gravar Evento!");
                    }
                }
                else
                {
                    RegEv.IdEvento = Convert.ToInt32(txtIDEvento.Text);

                    if (RegEv.Alterar() > 0)
                    {
                        MessageBox.Show("Evento alterado com sucesso!");

                        Evento R = new Evento();
                        dsEvento.Tables.Clear();
                        dsEvento.Tables.Add(R.Listar());
                        bnEvento.DataSource = dsEvento.Tables["Evento"];

                        cbxCidade.Enabled = false;
                        cbxTipo.Enabled = false;
                        cbxNivelSeveridade.Enabled = false;
                        mskBxPopAfetada.Enabled = false;
                        mskBxAreaAfetada.Enabled = false;
                        txtObservacao.Enabled = false;
                        dtpDataOcorrencia.Enabled = false;

                        btnSalvar.Enabled = false;
                        btnAlterar.Enabled = true;
                        btnNovo.Enabled = true;
                        btnExcluir.Enabled = true;
                        btnCancelar.Enabled = true;

                    }
                    else
                    {
                        MessageBox.Show("Erro ao gravar Evento!");
                    }

                }
            }
        }
        private void btnExcluir_Click(object sender, EventArgs e)
        {
            if (tbEvento.SelectedIndex == 0)
            {
                tbEvento.SelectTab(1);
            }

            if (MessageBox.Show("Confirma exclusão?", "Sim ou Não",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question,
                MessageBoxDefaultButton.Button2) == DialogResult.Yes)
            {
                Evento RegEv = new Evento();

                RegEv.IdEvento = Convert.ToInt16(txtIDEvento.Text);

                if (RegEv.Excluir() > 0)
                {
                    MessageBox.Show("Evento excluído com sucesso!");

                    Evento R = new Evento();
                    dsEvento.Tables.Clear();
                    dsEvento.Tables.Add(R.Listar());
                    bnEvento.DataSource = dsEvento.Tables["Evento"];
                }
                else
                {
                    MessageBox.Show("Erro ao excluir Evento!");
                }
            }
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            bnEvento.CancelEdit();

            cbxCidade.Enabled = false;
            cbxTipo.Enabled = false;
            cbxNivelSeveridade.Enabled = false;
            mskBxPopAfetada.Enabled = false;
            mskBxAreaAfetada.Enabled=false;
            txtObservacao.Enabled = false;
            dtpDataOcorrencia.Enabled = false;


            btnSalvar.Enabled = false;
            btnAlterar.Enabled = true;
            btnNovo.Enabled = true;
            btnExcluir.Enabled = true;
            btnCancelar.Enabled = false;

            bInclusao = false;
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}




