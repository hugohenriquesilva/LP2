﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMetodos
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }
        
        private void btnContNum_Click(object sender, EventArgs e)
        {
            string textao = richTxtFrase.Text;
            int contNumber = 0; 
            int contador = 0;
            while (contador < textao.Length) 
            {
                if (char.IsNumber(textao[contador]))
                {
                    contNumber ++;
                }             
                
                contador ++;
            }
            MessageBox.Show($"A quantidade de números no texto ao lado é de: {contNumber}");
            

        }
        /*
        private void btnCaracter_Click(object sender, EventArgs e)
        {
            string textao = richTxtFrase.Text;
            int i;

            for (i = 0; i < textao.Length; i++)
            {
                if (char.IsWhiteSpace(textao[i]))
                {
                    break;
                }
            }
            MessageBox.Show($"A posição do primeiro espaço em branco é  {i+1}");

        }
        
        private void btnVerificBranco_Click(object sender, EventArgs e)
        {
            string textao = richTxtFrase.Text;
            int i;

            for (i = 0; i < textao.Length; i++)
            {
                if (char.IsWhiteSpace(textao[i]))
                {
                    break;
                }
            }
            MessageBox.Show($"A posição do primeiro espaço em branco é  {i + 1}");

        }*/

        private void btnVerificBranco_Click_1(object sender, EventArgs e)
        {
            string textao = richTxtFrase.Text;
            int i;

            for (i = 0; i < textao.Length; i++)
            {
                if (char.IsWhiteSpace(textao[i]))
                {
                    break;
                }
            }
            MessageBox.Show($"A posição do primeiro espaço em branco é  {i + 1}");
        }

        private void btnCaracter_Click(object sender, EventArgs e)
        {
            string[] textao = new string[richTxtFrase.Text.Length];
            int contador = 0;

            foreach (var i in textao)
            {
                contador++;
            }

            MessageBox.Show ($"A quantidade de caracteres é {contador}");

        }




        /*
        private void button1_Click(object sender, EventArgs e)
        {

        }
        */


    }

}
