﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMetodos
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnSorteio_Click(object sender, EventArgs e)
        {
            Random sorteio = new Random();
            int resultado;

            int number1 = Convert.ToInt32(txtNumber1.Text);
            int number2 = Convert.ToInt32(txtNumber2.Text);

            resultado = sorteio.Next(number1, number2 +1);

            MessageBox.Show($"O número sorteado é: {resultado}");
        }
        /*
private void button1_Click(object sender, EventArgs e)
{
   Random sorteio = new Random();
   int 
}
*/

    }
}
