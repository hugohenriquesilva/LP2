﻿namespace PTesteMetodos
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.richTxtFrase = new System.Windows.Forms.RichTextBox();
            this.btnContNum = new System.Windows.Forms.Button();
            this.btnVerificBranco = new System.Windows.Forms.Button();
            this.btnCaracter = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // richTxtFrase
            // 
            this.richTxtFrase.Location = new System.Drawing.Point(54, 33);
            this.richTxtFrase.Name = "richTxtFrase";
            this.richTxtFrase.Size = new System.Drawing.Size(224, 374);
            this.richTxtFrase.TabIndex = 0;
            this.richTxtFrase.Text = "";
            // 
            // btnContNum
            // 
            this.btnContNum.Location = new System.Drawing.Point(306, 33);
            this.btnContNum.Name = "btnContNum";
            this.btnContNum.Size = new System.Drawing.Size(209, 132);
            this.btnContNum.TabIndex = 1;
            this.btnContNum.Text = "verificar quantos caracteres numericos tem o texto";
            this.btnContNum.UseVisualStyleBackColor = true;
            this.btnContNum.Click += new System.EventHandler(this.btnContNum_Click);
            // 
            // btnVerificBranco
            // 
            this.btnVerificBranco.Location = new System.Drawing.Point(306, 187);
            this.btnVerificBranco.Name = "btnVerificBranco";
            this.btnVerificBranco.Size = new System.Drawing.Size(209, 128);
            this.btnVerificBranco.TabIndex = 2;
            this.btnVerificBranco.Text = "Verificar a posição do primeiro branco ";
            this.btnVerificBranco.UseVisualStyleBackColor = true;
            this.btnVerificBranco.Click += new System.EventHandler(this.btnVerificBranco_Click_1);
            // 
            // btnCaracter
            // 
            this.btnCaracter.Location = new System.Drawing.Point(540, 33);
            this.btnCaracter.Name = "btnCaracter";
            this.btnCaracter.Size = new System.Drawing.Size(206, 132);
            this.btnCaracter.TabIndex = 3;
            this.btnCaracter.Text = "Contar quantos caracteres alfabéticos";
            this.btnCaracter.UseVisualStyleBackColor = true;
            this.btnCaracter.Click += new System.EventHandler(this.btnCaracter_Click);
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnCaracter);
            this.Controls.Add(this.btnVerificBranco);
            this.Controls.Add(this.btnContNum);
            this.Controls.Add(this.richTxtFrase);
            this.Name = "frmExercicio4";
            this.Text = "frmExercicio4";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox richTxtFrase;
        private System.Windows.Forms.Button btnContNum;
        private System.Windows.Forms.Button btnVerificBranco;
        private System.Windows.Forms.Button btnCaracter;
    }
}