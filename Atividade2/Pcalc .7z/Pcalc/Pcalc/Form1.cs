﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pcalc
{
    public partial class Form1 : Form
    {
        Double numero1, numero2, resultado;
        
    
        public Form1()
        {
            InitializeComponent();
        }

      
   

        
        private void btnDiv_Click(object sender, EventArgs e)
        {
            if (numero2 == 0)
            {
                MessageBox.Show("Não é possível dividir por 0");
                lblNumero2.Focus();
            }
            else
            {
                resultado = numero1 / numero2;
                lblResultado.Text = resultado.ToString();
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            resultado = numero1 + numero2;
            lblResultado.Text = resultado.ToString();
        }

        private void btnSub_Click(object sender, EventArgs e)
        {
            resultado = numero1 - numero2;
            lblResultado.Text = resultado.ToString();
        }

        private void btnMult_Click(object sender, EventArgs e)
        {
            resultado = numero1 * numero2;
            lblResultado.Text = resultado.ToString();
        }

        private void lblNumero1_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(lblNumero1.Text, out numero1))
            {
                MessageBox.Show("Número1 invalido!");
                lblNumero1.Focus();
            }
        }

        private void lblNumero2_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(lblNumero2.Text, out numero2))
            {
                MessageBox.Show("Número 2 invalido!");
                lblNumero2.Focus();
            }
        }

        private void btnLimpar_Click_1(object sender, EventArgs e)
        {
            lblNumero1.Text = null;
            lblNumero2.Text = null;
            lblResultado.Text = null;
        }

        private void txtResultado_Validated(object sender, EventArgs e)
        {
            if(!double.TryParse(lblResultado.Text,out resultado))
            {
                MessageBox.Show("Resultado inválido!");
                lblResultado.Focus();
            }
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Você realmente deseja sair", "Saida", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes) Close();

        }
    }
}
