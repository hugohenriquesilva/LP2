﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade5
{
    public partial class Form1 : Form
    {

        double SalBruto, SalLiq, DescIRPF, DescINSS, SalFamil;

        private void txtNome_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsNumber(e.KeyChar) || char.IsPunctuation(e.KeyChar))
            {
                MessageBox.Show("Caracter inválido");
                SendKeys.Send("{backspace}");
            }
        }

        double numFilh;

       

        private void btnVerific_Click(object sender, EventArgs e)
        {

            // Esse if é para o cálculo do desconto do INSS

            if (SalBruto < 800.47)
            {
                txtAliqINSS.Text = "7,65%";                
                DescINSS = SalBruto * 0.0765;
            }
            else if (SalBruto < 1050.50)
            {
                txtAliqINSS.Text = "8,65%";                
                DescINSS = SalBruto * 0.0865;
            }
            else if (SalBruto < 1400.77)
            {
                txtAliqINSS.Text = "9,00%";                
                DescINSS = SalBruto * 0.09;
            }
            else if (SalBruto < 2800.56)
            {
                txtAliqINSS.Text = "11,00%";                
                DescINSS = SalBruto * 0.11;
            }
            else
            {
                txtAliqINSS.Text = "TETO";
                DescINSS = SalBruto - 308.17;                
            }

            //Esse trecho de código se refere ao desconto do IRPF
           
            if (SalBruto < 1257.12)
            {
                txtAliqIRPF.Text = "ISENTO";
                DescIRPF = SalBruto * 0;             
            }
            else if (SalBruto < 2512.08)
            {
                txtAliqIRPF.Text = "15,00%";
                DescIRPF = SalBruto * 0.15;                       
            }
            else 
            {
                txtAliqIRPF.Text = "27,50%";
                DescIRPF = SalBruto * 0.275;
            }


            // a partir daqui, o if é direcionado para os filhos 
            numFilh = Convert.ToDouble(numUpDownFilhos.Value);

            if (SalBruto < 435.52)
            {
                SalFamil = 22.33 * numFilh;
            }
            else if (SalBruto < 654.61)
            {
                SalFamil = 15.74 * numFilh;
            }
            else
            {
                SalFamil = 0;
            }

            //Atribuindo aos textos de desconto os valores em double correspondentes ao desconto
            txtDescINSS.Text = DescINSS.ToString("C2");
            txtDescIRPF.Text = DescIRPF.ToString("C2");
            txtSalFamil.Text = SalFamil.ToString("C2"); //atribui a conta para cima e faz tostring na variavel
            
            //Gerando o valor líquido
            SalLiq = SalBruto - (DescINSS + DescIRPF) + SalFamil;
            txtSalLiq.Text = SalLiq.ToString("C2");
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void mskTxtSalBruto_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(mskTxtSalBruto.Text, out SalBruto))
                MessageBox.Show("Coloque um valor válido");
                       
        }
    }
}
