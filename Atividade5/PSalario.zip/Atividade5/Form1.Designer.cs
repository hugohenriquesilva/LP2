﻿namespace Atividade5
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNome = new System.Windows.Forms.Label();
            this.lblSalLiq = new System.Windows.Forms.Label();
            this.lblAliqIRPF = new System.Windows.Forms.Label();
            this.lblAliqINSS = new System.Windows.Forms.Label();
            this.lblNumFilhos = new System.Windows.Forms.Label();
            this.lblSalBruto = new System.Windows.Forms.Label();
            this.lblDescINSS = new System.Windows.Forms.Label();
            this.lblDescIRPF = new System.Windows.Forms.Label();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.txtAliqINSS = new System.Windows.Forms.TextBox();
            this.txtDescINSS = new System.Windows.Forms.TextBox();
            this.txtSalLiq = new System.Windows.Forms.TextBox();
            this.txtAliqIRPF = new System.Windows.Forms.TextBox();
            this.txtDescIRPF = new System.Windows.Forms.TextBox();
            this.numUpDownFilhos = new System.Windows.Forms.NumericUpDown();
            this.mskTxtSalBruto = new System.Windows.Forms.MaskedTextBox();
            this.btnVerific = new System.Windows.Forms.Button();
            this.lblSalFamil = new System.Windows.Forms.Label();
            this.txtSalFamil = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDownFilhos)).BeginInit();
            this.SuspendLayout();
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Location = new System.Drawing.Point(48, 58);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(128, 16);
            this.lblNome.TabIndex = 0;
            this.lblNome.Text = "COLOQUE O NOME";
            // 
            // lblSalLiq
            // 
            this.lblSalLiq.AutoSize = true;
            this.lblSalLiq.Location = new System.Drawing.Point(37, 355);
            this.lblSalLiq.Name = "lblSalLiq";
            this.lblSalLiq.Size = new System.Drawing.Size(120, 16);
            this.lblSalLiq.TabIndex = 1;
            this.lblSalLiq.Text = "SALÁRIO LÍQUIDO";
            // 
            // lblAliqIRPF
            // 
            this.lblAliqIRPF.AutoSize = true;
            this.lblAliqIRPF.Location = new System.Drawing.Point(40, 281);
            this.lblAliqIRPF.Name = "lblAliqIRPF";
            this.lblAliqIRPF.Size = new System.Drawing.Size(107, 16);
            this.lblAliqIRPF.TabIndex = 2;
            this.lblAliqIRPF.Text = "ALÍQUOTA IRPF";
            // 
            // lblAliqINSS
            // 
            this.lblAliqINSS.AutoSize = true;
            this.lblAliqINSS.Location = new System.Drawing.Point(39, 246);
            this.lblAliqINSS.Name = "lblAliqINSS";
            this.lblAliqINSS.Size = new System.Drawing.Size(108, 16);
            this.lblAliqINSS.TabIndex = 3;
            this.lblAliqINSS.Text = "ALÍQUOTA INSS";
            // 
            // lblNumFilhos
            // 
            this.lblNumFilhos.AutoSize = true;
            this.lblNumFilhos.Location = new System.Drawing.Point(48, 140);
            this.lblNumFilhos.Name = "lblNumFilhos";
            this.lblNumFilhos.Size = new System.Drawing.Size(139, 16);
            this.lblNumFilhos.TabIndex = 4;
            this.lblNumFilhos.Text = "NÚMERO DE FILHOS";
            // 
            // lblSalBruto
            // 
            this.lblSalBruto.AutoSize = true;
            this.lblSalBruto.Location = new System.Drawing.Point(48, 94);
            this.lblSalBruto.Name = "lblSalBruto";
            this.lblSalBruto.Size = new System.Drawing.Size(115, 16);
            this.lblSalBruto.TabIndex = 5;
            this.lblSalBruto.Text = "SALÁRIO BRUTO";
            // 
            // lblDescINSS
            // 
            this.lblDescINSS.AutoSize = true;
            this.lblDescINSS.Location = new System.Drawing.Point(378, 246);
            this.lblDescINSS.Name = "lblDescINSS";
            this.lblDescINSS.Size = new System.Drawing.Size(117, 16);
            this.lblDescINSS.TabIndex = 6;
            this.lblDescINSS.Text = "DESCONTO INSS";
            // 
            // lblDescIRPF
            // 
            this.lblDescIRPF.AutoSize = true;
            this.lblDescIRPF.Location = new System.Drawing.Point(378, 281);
            this.lblDescIRPF.Name = "lblDescIRPF";
            this.lblDescIRPF.Size = new System.Drawing.Size(116, 16);
            this.lblDescIRPF.TabIndex = 7;
            this.lblDescIRPF.Text = "DESCONTO IRPF";
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(206, 52);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(394, 22);
            this.txtNome.TabIndex = 9;
            this.txtNome.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNome_KeyPress);
            // 
            // txtAliqINSS
            // 
            this.txtAliqINSS.Enabled = false;
            this.txtAliqINSS.Location = new System.Drawing.Point(178, 240);
            this.txtAliqINSS.Name = "txtAliqINSS";
            this.txtAliqINSS.Size = new System.Drawing.Size(179, 22);
            this.txtAliqINSS.TabIndex = 10;
            // 
            // txtDescINSS
            // 
            this.txtDescINSS.Enabled = false;
            this.txtDescINSS.Location = new System.Drawing.Point(535, 240);
            this.txtDescINSS.Name = "txtDescINSS";
            this.txtDescINSS.Size = new System.Drawing.Size(179, 22);
            this.txtDescINSS.TabIndex = 11;
            // 
            // txtSalLiq
            // 
            this.txtSalLiq.Enabled = false;
            this.txtSalLiq.Location = new System.Drawing.Point(178, 349);
            this.txtSalLiq.Name = "txtSalLiq";
            this.txtSalLiq.Size = new System.Drawing.Size(179, 22);
            this.txtSalLiq.TabIndex = 12;
            // 
            // txtAliqIRPF
            // 
            this.txtAliqIRPF.Enabled = false;
            this.txtAliqIRPF.Location = new System.Drawing.Point(178, 275);
            this.txtAliqIRPF.Name = "txtAliqIRPF";
            this.txtAliqIRPF.Size = new System.Drawing.Size(179, 22);
            this.txtAliqIRPF.TabIndex = 13;
            // 
            // txtDescIRPF
            // 
            this.txtDescIRPF.Enabled = false;
            this.txtDescIRPF.Location = new System.Drawing.Point(535, 275);
            this.txtDescIRPF.Name = "txtDescIRPF";
            this.txtDescIRPF.Size = new System.Drawing.Size(179, 22);
            this.txtDescIRPF.TabIndex = 15;
            // 
            // numUpDownFilhos
            // 
            this.numUpDownFilhos.Location = new System.Drawing.Point(206, 134);
            this.numUpDownFilhos.Name = "numUpDownFilhos";
            this.numUpDownFilhos.Size = new System.Drawing.Size(120, 22);
            this.numUpDownFilhos.TabIndex = 16;
            // 
            // mskTxtSalBruto
            // 
            this.mskTxtSalBruto.Location = new System.Drawing.Point(206, 88);
            this.mskTxtSalBruto.Mask = "99000.00";
            this.mskTxtSalBruto.Name = "mskTxtSalBruto";
            this.mskTxtSalBruto.Size = new System.Drawing.Size(120, 22);
            this.mskTxtSalBruto.TabIndex = 17;
            this.mskTxtSalBruto.Validated += new System.EventHandler(this.mskTxtSalBruto_Validated);
            // 
            // btnVerific
            // 
            this.btnVerific.Location = new System.Drawing.Point(255, 177);
            this.btnVerific.Name = "btnVerific";
            this.btnVerific.Size = new System.Drawing.Size(204, 33);
            this.btnVerific.TabIndex = 18;
            this.btnVerific.Text = "Verificar desconto";
            this.btnVerific.UseVisualStyleBackColor = true;
            this.btnVerific.Click += new System.EventHandler(this.btnVerific_Click);
            // 
            // lblSalFamil
            // 
            this.lblSalFamil.AutoSize = true;
            this.lblSalFamil.Location = new System.Drawing.Point(37, 318);
            this.lblSalFamil.Name = "lblSalFamil";
            this.lblSalFamil.Size = new System.Drawing.Size(117, 16);
            this.lblSalFamil.TabIndex = 19;
            this.lblSalFamil.Text = "SALÁRIO FAMÍLIA";
            // 
            // txtSalFamil
            // 
            this.txtSalFamil.Enabled = false;
            this.txtSalFamil.Location = new System.Drawing.Point(178, 312);
            this.txtSalFamil.Name = "txtSalFamil";
            this.txtSalFamil.Size = new System.Drawing.Size(179, 22);
            this.txtSalFamil.TabIndex = 20;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.txtSalFamil);
            this.Controls.Add(this.lblSalFamil);
            this.Controls.Add(this.btnVerific);
            this.Controls.Add(this.mskTxtSalBruto);
            this.Controls.Add(this.numUpDownFilhos);
            this.Controls.Add(this.txtDescIRPF);
            this.Controls.Add(this.txtAliqIRPF);
            this.Controls.Add(this.txtSalLiq);
            this.Controls.Add(this.txtDescINSS);
            this.Controls.Add(this.txtAliqINSS);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.lblDescIRPF);
            this.Controls.Add(this.lblDescINSS);
            this.Controls.Add(this.lblSalBruto);
            this.Controls.Add(this.lblNumFilhos);
            this.Controls.Add(this.lblAliqINSS);
            this.Controls.Add(this.lblAliqIRPF);
            this.Controls.Add(this.lblSalLiq);
            this.Controls.Add(this.lblNome);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.numUpDownFilhos)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label lblSalLiq;
        private System.Windows.Forms.Label lblAliqIRPF;
        private System.Windows.Forms.Label lblAliqINSS;
        private System.Windows.Forms.Label lblNumFilhos;
        private System.Windows.Forms.Label lblSalBruto;
        private System.Windows.Forms.Label lblDescINSS;
        private System.Windows.Forms.Label lblDescIRPF;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.TextBox txtAliqINSS;
        private System.Windows.Forms.TextBox txtDescINSS;
        private System.Windows.Forms.TextBox txtSalLiq;
        private System.Windows.Forms.TextBox txtAliqIRPF;
        private System.Windows.Forms.TextBox txtDescIRPF;
        private System.Windows.Forms.NumericUpDown numUpDownFilhos;
        private System.Windows.Forms.MaskedTextBox mskTxtSalBruto;
        private System.Windows.Forms.Button btnVerific;
        private System.Windows.Forms.Label lblSalFamil;
        private System.Windows.Forms.TextBox txtSalFamil;
    }
}

