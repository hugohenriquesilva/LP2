﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMatrizes
{
    public partial class frmExercicio2 : Form
    {
        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            ArrayList nome = new ArrayList()
            { "Ana", "André", "Débora", "Fátima", "João", "Janete", "Otávio", "Marcelo", "Pedro", "Thais" };
            nome.Remove("Otávio");
            string auxiliar = "";

            foreach (string x in nome)
            {
                auxiliar += x + "\n";
            }
            MessageBox.Show($"Os nomes são: \n {auxiliar}");
        }
    }
}
