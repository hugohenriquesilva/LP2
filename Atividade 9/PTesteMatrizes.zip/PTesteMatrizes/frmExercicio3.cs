﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMatrizes
{
    public partial class frmExercicio3 : Form
    {
        public frmExercicio3()
        {
            InitializeComponent();
        }

        private void btnCalcula_Click(object sender, EventArgs e)
        {
            double[,] nota = new double[5, 3];
            double[] media = new double[5];
            string auxiliar = "";


            for (int i = 0; i < media.Length; i++)
            {
                double soma = 0;
                for (int j = 0; j < 3; j++)
                {
                    auxiliar = Interaction.InputBox($"Coloque a nota {j + 1} do {i + 1}° aluno");
                    if (double.TryParse(auxiliar, out nota[i, j]))
                    {
                        soma += nota[i, j];
                        
                    }
                }
                media[i] = soma / 3;
            }

            string template = "";

            for (int i = 0; i < media.Length; i++)
            {
                template += $"Aluno {i + 1}: média: {media[i]} \n";
            }

            MessageBox.Show(template);

        }
    }
}
