﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMatrizes
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnVerifica_Click(object sender, EventArgs e)
        {
            string[] nomes = new string[8];

            string nome;
            for (int i = 0; i < 8; i++)
            {
                nome = Interaction.InputBox("Digite um nome");

                nomes[i] = nome;
                int len = nome.Length;
                int contBranco = 0;

                for (int j = 0; j < len; j++)
                {
                    if (char.IsWhiteSpace(nome[j]))
                    {
                        contBranco++;
                    }


                }
                int totalCarc = len - contBranco;

                listBox1.Items.Add("O nome:" + nome + " tem " + totalCarc + " caracteres");

            }
        }
}
