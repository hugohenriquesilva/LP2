﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMatrizes
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            char[,] prova = new char[3, 10];
            char[] gabarito = new char[] { 'A', 'B', 'C', 'D', 'E', 'A', 'B', 'C', 'D', 'E' };
            int acertos = 0;
            int a = 0;

            string respostas;
            for (a = 0; a < 2; a++)
            {
                for (int i = 0; i < 10; i++)
                {
                    respostas = Interaction.InputBox("Digite a resposta da questão " + (i + 1));


                    listBox1.Items.Add("Aluno " + (a + 1) + ", a resposta da questão " + (i + 1) + " é: " + respostas);



                    prova[a, i] = Convert.ToChar(respostas);

                    // Char.ToUpper(prova[a,i]);

                    if (Char.ToUpper(prova[a, i]) == gabarito[i])
                    {
                        acertos++;
                    }



                }
                MessageBox.Show($"O aluno {a + 1} acertou {acertos} questões ");

                acertos = 0;
            }


        }
    }
}
