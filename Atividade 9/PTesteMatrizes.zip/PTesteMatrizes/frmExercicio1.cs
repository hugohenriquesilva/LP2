﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMatrizes
{
    public partial class frmExercicio1 : Form
    {
        public frmExercicio1()
        {
            InitializeComponent();
        }

        private void btnInverte_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[4];
            string auxiliar;
            for (int i = 0; i < vetor.Length; i++)
            {
                auxiliar = Interaction.InputBox($"Digite o {i + 1}° número", "entrada de dados");
                if (!int.TryParse(auxiliar, out vetor[i]))
                {
                    MessageBox.Show("Insira valor válido");
                    i--;
                }
            }
            Array.Reverse(vetor);
            auxiliar = "";
            foreach (int x in vetor)
                auxiliar += x + "\n";

            MessageBox.Show($"Os números com a ordem invertida são: \n{auxiliar}");
        }
    }
}
