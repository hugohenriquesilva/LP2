﻿namespace Atividade8
{
    partial class frmOpcaoQuatro
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNome = new System.Windows.Forms.Label();
            this.lblMatricula = new System.Windows.Forms.Label();
            this.lblProducao = new System.Windows.Forms.Label();
            this.lblSalario = new System.Windows.Forms.Label();
            this.lblGrati = new System.Windows.Forms.Label();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.txtProducao = new System.Windows.Forms.TextBox();
            this.txtMatric = new System.Windows.Forms.TextBox();
            this.mskTxtSalario = new System.Windows.Forms.MaskedTextBox();
            this.mskTxtGratifi = new System.Windows.Forms.MaskedTextBox();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.lblSalBruto = new System.Windows.Forms.Label();
            this.txtSalBruto = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Location = new System.Drawing.Point(88, 62);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(47, 16);
            this.lblNome.TabIndex = 0;
            this.lblNome.Text = "Nome ";
            // 
            // lblMatricula
            // 
            this.lblMatricula.AutoSize = true;
            this.lblMatricula.Location = new System.Drawing.Point(88, 92);
            this.lblMatricula.Name = "lblMatricula";
            this.lblMatricula.Size = new System.Drawing.Size(61, 16);
            this.lblMatricula.TabIndex = 1;
            this.lblMatricula.Text = "Matrícula";
            // 
            // lblProducao
            // 
            this.lblProducao.AutoSize = true;
            this.lblProducao.Location = new System.Drawing.Point(88, 126);
            this.lblProducao.Name = "lblProducao";
            this.lblProducao.Size = new System.Drawing.Size(69, 16);
            this.lblProducao.TabIndex = 2;
            this.lblProducao.Text = "Produção ";
            // 
            // lblSalario
            // 
            this.lblSalario.AutoSize = true;
            this.lblSalario.Location = new System.Drawing.Point(88, 160);
            this.lblSalario.Name = "lblSalario";
            this.lblSalario.Size = new System.Drawing.Size(53, 16);
            this.lblSalario.TabIndex = 3;
            this.lblSalario.Text = "Salário ";
            // 
            // lblGrati
            // 
            this.lblGrati.AutoSize = true;
            this.lblGrati.Location = new System.Drawing.Point(88, 193);
            this.lblGrati.Name = "lblGrati";
            this.lblGrati.Size = new System.Drawing.Size(79, 16);
            this.lblGrati.TabIndex = 4;
            this.lblGrati.Text = "Gratificação";
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(191, 62);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(342, 22);
            this.txtNome.TabIndex = 5;
            this.txtNome.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNome_KeyPress);
            // 
            // txtProducao
            // 
            this.txtProducao.Location = new System.Drawing.Point(191, 123);
            this.txtProducao.Name = "txtProducao";
            this.txtProducao.Size = new System.Drawing.Size(342, 22);
            this.txtProducao.TabIndex = 8;
            this.txtProducao.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtProducao_KeyPress);
            // 
            // txtMatric
            // 
            this.txtMatric.Location = new System.Drawing.Point(191, 92);
            this.txtMatric.Name = "txtMatric";
            this.txtMatric.Size = new System.Drawing.Size(342, 22);
            this.txtMatric.TabIndex = 9;
            this.txtMatric.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtMatric_KeyPress);
            // 
            // mskTxtSalario
            // 
            this.mskTxtSalario.Location = new System.Drawing.Point(191, 160);
            this.mskTxtSalario.Mask = "99000.00";
            this.mskTxtSalario.Name = "mskTxtSalario";
            this.mskTxtSalario.Size = new System.Drawing.Size(187, 22);
            this.mskTxtSalario.TabIndex = 10;
            this.mskTxtSalario.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.mskTxtSalario_KeyPress);
            // 
            // mskTxtGratifi
            // 
            this.mskTxtGratifi.Location = new System.Drawing.Point(191, 190);
            this.mskTxtGratifi.Mask = "99000.00";
            this.mskTxtGratifi.Name = "mskTxtGratifi";
            this.mskTxtGratifi.Size = new System.Drawing.Size(187, 22);
            this.mskTxtGratifi.TabIndex = 11;
            this.mskTxtGratifi.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.mskTxtGratifi_KeyPress);
            // 
            // btnLimpar
            // 
            this.btnLimpar.Location = new System.Drawing.Point(575, 146);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(197, 44);
            this.btnLimpar.TabIndex = 12;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = true;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // btnCalcular
            // 
            this.btnCalcular.Location = new System.Drawing.Point(575, 64);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(197, 44);
            this.btnCalcular.TabIndex = 13;
            this.btnCalcular.Text = "Calcular";
            this.btnCalcular.UseVisualStyleBackColor = true;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // lblSalBruto
            // 
            this.lblSalBruto.AutoSize = true;
            this.lblSalBruto.Location = new System.Drawing.Point(115, 349);
            this.lblSalBruto.Name = "lblSalBruto";
            this.lblSalBruto.Size = new System.Drawing.Size(41, 16);
            this.lblSalBruto.TabIndex = 14;
            this.lblSalBruto.Text = "Total ";
            // 
            // txtSalBruto
            // 
            this.txtSalBruto.Location = new System.Drawing.Point(179, 346);
            this.txtSalBruto.Name = "txtSalBruto";
            this.txtSalBruto.Size = new System.Drawing.Size(342, 22);
            this.txtSalBruto.TabIndex = 15;
            // 
            // frmOpcaoQuatro
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.txtSalBruto);
            this.Controls.Add(this.lblSalBruto);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.mskTxtGratifi);
            this.Controls.Add(this.mskTxtSalario);
            this.Controls.Add(this.txtMatric);
            this.Controls.Add(this.txtProducao);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.lblGrati);
            this.Controls.Add(this.lblSalario);
            this.Controls.Add(this.lblProducao);
            this.Controls.Add(this.lblMatricula);
            this.Controls.Add(this.lblNome);
            this.Name = "frmOpcaoQuatro";
            this.Text = "frmOpcaoQuatro";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label lblMatricula;
        private System.Windows.Forms.Label lblProducao;
        private System.Windows.Forms.Label lblSalario;
        private System.Windows.Forms.Label lblGrati;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.TextBox txtProducao;
        private System.Windows.Forms.TextBox txtMatric;
        private System.Windows.Forms.MaskedTextBox mskTxtSalario;
        private System.Windows.Forms.MaskedTextBox mskTxtGratifi;
        private System.Windows.Forms.Button btnLimpar;
        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.Label lblSalBruto;
        private System.Windows.Forms.TextBox txtSalBruto;
    }
}