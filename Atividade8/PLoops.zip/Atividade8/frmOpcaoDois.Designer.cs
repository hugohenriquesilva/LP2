﻿namespace Atividade8
{
    partial class frmOpcaoDois
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNumero = new System.Windows.Forms.Label();
            this.lblNumGerado = new System.Windows.Forms.Label();
            this.txtNumero = new System.Windows.Forms.TextBox();
            this.txtNumGerado = new System.Windows.Forms.TextBox();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblNumero
            // 
            this.lblNumero.AutoSize = true;
            this.lblNumero.Location = new System.Drawing.Point(62, 77);
            this.lblNumero.Name = "lblNumero";
            this.lblNumero.Size = new System.Drawing.Size(197, 16);
            this.lblNumero.TabIndex = 0;
            this.lblNumero.Text = "Digite o número que quer contar";
            // 
            // lblNumGerado
            // 
            this.lblNumGerado.AutoSize = true;
            this.lblNumGerado.Location = new System.Drawing.Point(81, 195);
            this.lblNumGerado.Name = "lblNumGerado";
            this.lblNumGerado.Size = new System.Drawing.Size(126, 16);
            this.lblNumGerado.TabIndex = 1;
            this.lblNumGerado.Text = "O número gerado é:";
            // 
            // txtNumero
            // 
            this.txtNumero.Location = new System.Drawing.Point(321, 77);
            this.txtNumero.Name = "txtNumero";
            this.txtNumero.Size = new System.Drawing.Size(221, 22);
            this.txtNumero.TabIndex = 2;
            // 
            // txtNumGerado
            // 
            this.txtNumGerado.Enabled = false;
            this.txtNumGerado.Location = new System.Drawing.Point(321, 195);
            this.txtNumGerado.Name = "txtNumGerado";
            this.txtNumGerado.Size = new System.Drawing.Size(221, 22);
            this.txtNumGerado.TabIndex = 3;
            // 
            // btnCalcular
            // 
            this.btnCalcular.Location = new System.Drawing.Point(585, 125);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(158, 29);
            this.btnCalcular.TabIndex = 4;
            this.btnCalcular.Text = "Calcular";
            this.btnCalcular.UseVisualStyleBackColor = true;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // frmOpcaoDois
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.txtNumGerado);
            this.Controls.Add(this.txtNumero);
            this.Controls.Add(this.lblNumGerado);
            this.Controls.Add(this.lblNumero);
            this.Name = "frmOpcaoDois";
            this.Text = "frmOpcaoDois";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNumero;
        private System.Windows.Forms.Label lblNumGerado;
        private System.Windows.Forms.TextBox txtNumero;
        private System.Windows.Forms.TextBox txtNumGerado;
        private System.Windows.Forms.Button btnCalcular;
    }
}