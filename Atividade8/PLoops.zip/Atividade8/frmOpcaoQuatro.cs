﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade8
{
    public partial class frmOpcaoQuatro : Form
    {
        public frmOpcaoQuatro()
        {
            InitializeComponent();
        }
        double salario, salarioBruto, gratifica, producao, B = 0, C = 0, D = 0;

        private void mskTxtGratifi_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(char.IsPunctuation(e.KeyChar) || char.IsLetter(e.KeyChar))
            {
                MessageBox.Show("Coloque uma gratificação válida");
                SendKeys.Send("{BACKSPACE}");
            }
        }

        private void mskTxtSalario_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsPunctuation(e.KeyChar) || char.IsLetter(e.KeyChar))
            {
                MessageBox.Show("Coloque um salário válido");
                SendKeys.Send("{BACKSPACE}");
            }
        }

        private void txtProducao_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsPunctuation(e.KeyChar) || char.IsLetter(e.KeyChar))
            {
                MessageBox.Show("Coloque uma produção válida");
                SendKeys.Send("{BACKSPACE}");
            }
        }

        private void txtMatric_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(char.IsPunctuation(e.KeyChar) || char.IsLetter(e.KeyChar))
            {
                MessageBox.Show("Coloque uma matrícula válida");
                SendKeys.Send("{BACKSPACE}");
            }
        }

        private void txtNome_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(char.IsNumber(e.KeyChar) || char.IsPunctuation(e.KeyChar))
            {
                MessageBox.Show("Insira um nome válido");
                SendKeys.Send("{BACKSPACE}");
            }
        }

        /*
        private void txtNome_Validated(object sender, EventArgs e)
        {

        }*/

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (double.TryParse(txtProducao.Text, out producao) &&
                double.TryParse(mskTxtSalario.Text, out salario) &&
                double.TryParse(mskTxtGratifi.Text, out gratifica))
            
            // esse if calcula a produção            
            if(producao >= 100)
            {
                B = 1*0.05;
            }
            else if (producao >= 120)
            {
                B = 1 * 0.05;
                C = 1 * 0.1;
            }
            else if(producao >=150)
            {
                B = 1 * 0.05;
                C = 1 * 0.1;
                D = 1 * 0.1;
            }

            salarioBruto = salario + salario * (B + C + D) + gratifica;

            //verificar salário 
            if(salarioBruto >= 7000 && producao >=150 && gratifica >0)
            {

            }
            else
            {
                salarioBruto = 7000;
            }

            txtSalBruto.Text = salarioBruto.ToString("C2");
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNome.Text = string.Empty;
            txtMatric.Text = string.Empty;
            txtProducao.Text = string.Empty;
            mskTxtGratifi.Text = string.Empty;
            mskTxtSalario.Text = string.Empty;
            txtSalBruto.Text = string.Empty;
        }


    }
}
