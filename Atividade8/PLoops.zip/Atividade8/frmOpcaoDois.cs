﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade8
{
    public partial class frmOpcaoDois : Form
    {
        public frmOpcaoDois()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            int numeroN;
            float numeroH = 0;

            if ((!int.TryParse(txtNumero.Text, out numeroN)) || (numeroN < 0))
            {
                MessageBox.Show("Valor inválido, tente novamente");
                txtNumero.Focus();
            }
            else
            {
                for (float i = 0; i < numeroN; i++)
                {
                    numeroH += 1 / (i + 1);
                }
                txtNumGerado.Text = Convert.ToString(numeroH);

            }


        }
    }
}
