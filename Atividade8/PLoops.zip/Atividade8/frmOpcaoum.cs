﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade8
{
    public partial class frmOpcaoum : Form
    {
        public frmOpcaoum()
        {
            InitializeComponent();
        }

        private void btnEspacoBranco_Click(object sender, EventArgs e)
        {
            string textao = richTxtBoxUm.Text;
            int i, j = 0;
            for (i = 0; i < textao.Length; i++)
            {
                if (char.IsWhiteSpace(textao[i]))
                {
                    j++;
                }
            }
            MessageBox.Show($"O número de espaços em branco é {j}");
        }

        private void btnNumeroDeR_Click(object sender, EventArgs e)
        {
            string textao = richTxtBoxUm.Text;
            int contador = 0;                     

            foreach (char i in textao)
            {
                if (i == 'R' || i == 'r')
                {
                    contador++;
                }    
            }
            MessageBox.Show($"O número de R's encontrado na frase foi: {contador}");
        }

        private void btnLetraRepetida_Click(object sender, EventArgs e)
        {
            string textao = richTxtBoxUm.Text;
            int contador = 0;
            int contRepet = 0;
            while (contador < textao.Length -1)
            {
                if (textao[contador] == textao[contador+1])
                {
                    contRepet++;
                }
                contador++;
            }
            MessageBox.Show($"O número de vezes que aparecem letras repetidas é: {contRepet}");
        }
    }
}
