﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade8
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            this.IsMdiContainer = true;
        }

        private void opção1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmOpcaoum>().Count()>0)
            {
                Application.OpenForms["frmOpcaoUm"].BringToFront();
            }
            else
            {
                frmOpcaoum obj1 = new frmOpcaoum();
                obj1.MdiParent = this;
                obj1.WindowState = FormWindowState.Maximized;
                obj1.Show();
            }
        }

        private void opção2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmOpcaoDois>().Count()>0)
            {
                Application.OpenForms["frmOpcaoDois"].BringToFront();
            }
            else
            {
                frmOpcaoDois obj1 = new frmOpcaoDois();
                obj1.MdiParent = this;
                obj1.WindowState= FormWindowState.Maximized;
                obj1.Show();
            }

        }

        private void opção3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmOpcaoTres>().Count()>0)
            {
                Application.OpenForms["frmOpcaoTres"].BringToFront();
            }
            else
            {
                frmOpcaoTres obj1 = new frmOpcaoTres();
                obj1.MdiParent = this;
                obj1.WindowState = FormWindowState.Maximized;
                obj1.Show();
            }
        }

        private void opção4ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmOpcaoQuatro>().Count() > 0)
            {
                Application.OpenForms["frmOpcaoQuatro"].BringToFront();
            }
            else
            {
                frmOpcaoQuatro obj1 = new frmOpcaoQuatro();
                obj1.MdiParent = this;  
                obj1.WindowState=FormWindowState.Maximized;
                obj1.Show();
            }
        }

        private void sAIRToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }
    }   
}
