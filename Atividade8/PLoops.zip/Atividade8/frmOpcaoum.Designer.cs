﻿namespace Atividade8
{
    partial class frmOpcaoum
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.richTxtBoxUm = new System.Windows.Forms.RichTextBox();
            this.btnEspacoBranco = new System.Windows.Forms.Button();
            this.btnLetraRepetida = new System.Windows.Forms.Button();
            this.btnNumeroDeR = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // richTxtBoxUm
            // 
            this.richTxtBoxUm.Location = new System.Drawing.Point(40, 41);
            this.richTxtBoxUm.Name = "richTxtBoxUm";
            this.richTxtBoxUm.Size = new System.Drawing.Size(229, 332);
            this.richTxtBoxUm.TabIndex = 0;
            this.richTxtBoxUm.Text = "";
            // 
            // btnEspacoBranco
            // 
            this.btnEspacoBranco.Location = new System.Drawing.Point(297, 41);
            this.btnEspacoBranco.Name = "btnEspacoBranco";
            this.btnEspacoBranco.Size = new System.Drawing.Size(223, 87);
            this.btnEspacoBranco.TabIndex = 1;
            this.btnEspacoBranco.Text = "Número de espaços em branco ";
            this.btnEspacoBranco.UseVisualStyleBackColor = true;
            this.btnEspacoBranco.Click += new System.EventHandler(this.btnEspacoBranco_Click);
            // 
            // btnLetraRepetida
            // 
            this.btnLetraRepetida.Location = new System.Drawing.Point(421, 134);
            this.btnLetraRepetida.Name = "btnLetraRepetida";
            this.btnLetraRepetida.Size = new System.Drawing.Size(223, 87);
            this.btnLetraRepetida.TabIndex = 2;
            this.btnLetraRepetida.Text = "Número de letras repetidas";
            this.btnLetraRepetida.UseVisualStyleBackColor = true;
            this.btnLetraRepetida.Click += new System.EventHandler(this.btnLetraRepetida_Click);
            // 
            // btnNumeroDeR
            // 
            this.btnNumeroDeR.Location = new System.Drawing.Point(547, 41);
            this.btnNumeroDeR.Name = "btnNumeroDeR";
            this.btnNumeroDeR.Size = new System.Drawing.Size(223, 87);
            this.btnNumeroDeR.TabIndex = 3;
            this.btnNumeroDeR.Text = "Número de R\'s";
            this.btnNumeroDeR.UseVisualStyleBackColor = true;
            this.btnNumeroDeR.Click += new System.EventHandler(this.btnNumeroDeR_Click);
            // 
            // frmOpcaoum
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnNumeroDeR);
            this.Controls.Add(this.btnLetraRepetida);
            this.Controls.Add(this.btnEspacoBranco);
            this.Controls.Add(this.richTxtBoxUm);
            this.Name = "frmOpcaoum";
            this.Text = "frmOpcaoum";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox richTxtBoxUm;
        private System.Windows.Forms.Button btnEspacoBranco;
        private System.Windows.Forms.Button btnLetraRepetida;
        private System.Windows.Forms.Button btnNumeroDeR;
    }
}