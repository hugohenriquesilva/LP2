﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade8
{
    public partial class frmOpcaoTres : Form
    {
        public frmOpcaoTres()
        {
            InitializeComponent();
        }

        private void btnVerPalin_Click(object sender, EventArgs e)
        {
            string textoInicial = txtPalin.Text;
            string texto = textoInicial.ToUpper();
            string ultimoTexto = texto.Replace(" ", "");

            char[] vetorTexto = ultimoTexto.ToCharArray();
            Array.Reverse (vetorTexto);
            string inversao = new string(vetorTexto);

            if(ultimoTexto == inversao)
            {
                MessageBox.Show($"Seu novo texto é: {inversao}" + "\n\n" + "Se trata de um palíndromo");
            }
            else
            {
                MessageBox.Show($"Seu novo texto é: {inversao}" + "\n\n" + "Não se trata de um palíndromo");
            }
        }
    }
}
