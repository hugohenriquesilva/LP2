﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PVestibular
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnReceber_Click(object sender, EventArgs e)
        {
            int[,] vestibular = new int[2, 5];
            int[] soma = new int[2];
            string aux = "";
            int aux2 = 0, totalGeral = 0;


            for (int i = 0; i < 2; i++)
            {
                soma[i] = 0;
                for (int j = 0; j < 5; j++)
                {
                    aux = Interaction.InputBox($"Coloque a quantidade de alunos" +
                        $" do {i + 1}° curso, no ano {j + 1}:");
                    if (int.TryParse(aux, out aux2))
                    {
                        vestibular[i, j] = aux2;
                        soma[i] += vestibular[i, j];

                    }
                    else
                    {
                        MessageBox.Show("Digite um valor inteiro");
                    }
                }
            }
            totalGeral = soma[0]+ soma[1];

            string template1 = "", template2 = "", template3= "";

            for (int i = 0; i < 2; i++)
            {
                template2 += $"\nTotal do curso {i + 1}: {soma[i]}";
                for (int j = 0; j < 5; j++)
                {
                    template1 += $"\nTotal do curso {i + 1} no ano {j + 1}: {vestibular[i, j]}";
                }
            }

            template3 = Convert.ToString(totalGeral);

            
            listBoxRecebe.Items.Add(template1 + "\n" + template2 + "\n"+ template3);
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            listBoxRecebe.Items.Clear();
        }
    }
}
